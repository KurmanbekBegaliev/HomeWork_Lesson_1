package com.company;

public class Alabay {

}
