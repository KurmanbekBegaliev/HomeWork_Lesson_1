package com.company;

public enum EnumColor {
    WHITE, BLACK, GRAY, BROWN
}
