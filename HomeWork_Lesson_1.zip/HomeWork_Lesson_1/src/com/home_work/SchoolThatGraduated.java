package com.home_work;

public class SchoolThatGraduated {
    private String schoolNumber;
    private String schoolName;

    public SchoolThatGraduated(String schoolNumber, String schoolName) {
        this.schoolName = schoolName;
        this.schoolNumber = schoolNumber;
    }

    public String getSchoolNumber() {
        return schoolNumber;
    }

    public String getSchoolName() {
        return schoolName;
    }
}
