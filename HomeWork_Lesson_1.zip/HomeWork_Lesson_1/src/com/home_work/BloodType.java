package com.home_work;

public enum BloodType {
    FIRST, SECOND, THIRD, FOURTH
}
